TODO v11
========

* Refactoring: can we remove `this._elements`? What's it for, now that we have the entries in `this._observer.entries`?

Test
---

Test more modules

* [ ] autoinitialize
* [ ] purge
* [ ] reveal